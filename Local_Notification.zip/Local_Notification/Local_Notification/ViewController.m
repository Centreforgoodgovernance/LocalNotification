//
//  ViewController.m
//  Local_Notification
//
//  Created by Marripelli Santhosh on 04/01/16.
//  Copyright © 2016 Marripelli Santhosh. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)buttonclicked:(id)sender {
    
    NSDate *currentDate = [NSDate date];
    NSDate *datePlusOneMinute = [currentDate dateByAddingTimeInterval:10];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"DD-MM-YYY hh:mm:ss"];
    
    //Optionally for time zone conversions
    [formatter setTimeZone:[NSTimeZone localTimeZone]];
    NSString *stringFromDate = [formatter stringFromDate:datePlusOneMinute];
    
    NSLog(@"%@",stringFromDate);
    
    UILocalNotification *localNotification = [[UILocalNotification alloc] init];
    
    localNotification.fireDate = datePlusOneMinute;
    localNotification.repeatInterval=0;
    
    localNotification.alertBody = @"This is Notifcation APP Notification";
    
    
    localNotification.timeZone=[NSTimeZone localTimeZone];
    
    localNotification.soundName = UILocalNotificationDefaultSoundName;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
 }
@end
